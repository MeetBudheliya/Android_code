package com.example.ict2_02_exam;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "Employee", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table if not exists employee(emp_id int primary key autoincrement, emp_name text, emp_designation text, emp_phone text, emp_email text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
onCreate(sqLiteDatabase);
    }

    public void addEmployee(String emp_name, String emp_designation, String emp_phone, String emp_email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("emp_name",emp_name);
        cv.put("emp_designation",emp_designation);
        cv.put("emp_phone",emp_phone);
        cv.put("emp_email",emp_email);
        db.insert("Employee",null,cv);
        db.close();
    }

    public Cursor getEmployees(){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from Employee",null,null);
        return cursor;
    }
    public Cursor GetEmployeeByName(String name){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from Employee where emp_name=?",new String[]{name});
        return cursor;
    }
}
