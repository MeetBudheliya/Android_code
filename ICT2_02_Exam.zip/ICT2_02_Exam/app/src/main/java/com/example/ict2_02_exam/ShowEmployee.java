package com.example.ict2_02_exam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;

public class ShowEmployee extends AppCompatActivity {

    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_employee);

        StringBuffer buffer = new StringBuffer();
        AlertDialog.Builder builder = new AlertDialog.Builder(ShowEmployee.this);
        Cursor cursor = DB.getEmployees();
        while (cursor.moveToNext()){
            buffer.append("emp_id : " + cursor.getString(0) + "'\n");
            buffer.append("emp_name : " + cursor.getString(1) + "'\n");
            buffer.append("emp_designation : " + cursor.getString(2) + "'\n");
            buffer.append("emp_phone : " + cursor.getString(3) + "'\n");
            buffer.append("emp_email : " + cursor.getString(4) + "'\n");
            buffer.append("\n");
        }
        builder.setCancelable(true);
        builder.setTitle("Employee Records");
        builder.setMessage(buffer.toString());
        builder.show();
    }
}